/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateContactCommand = {
    firstName?: string | null;
    lastName?: string | null;
    title?: string | null;
    email?: string | null;
    phone?: string | null;
    note?: string | null;
    isActive?: boolean;
    isDefault?: boolean;
    category?: string | null;
    categoryID?: string | null;
};

