/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateFolderDto = {
    folderId?: string | null;
    name?: string | null;
    isActive?: boolean;
    isVoided?: boolean;
    createdBy?: string | null;
    createdDate?: string;
};

