/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateTicketPriorityDto = {
    ticketPriorityId?: string | null;
    name?: string | null;
    isVoided?: boolean;
    createdBy?: string | null;
    createdDate?: string;
};

