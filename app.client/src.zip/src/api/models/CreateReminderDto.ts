/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateReminderDto = {
    reminderId?: string | null;
    name?: string | null;
    description?: string | null;
    taskId?: string | null;
    reminderDate?: string | null;
    isRecurring?: boolean;
    isActive?: boolean;
    isVoided?: boolean;
    createdBy?: string | null;
    createdDate?: string;
    lastModifiedBy?: string | null;
    lastModifiedDate?: string | null;
};

